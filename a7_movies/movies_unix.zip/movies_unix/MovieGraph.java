/*

	MovieGraph.java
	COSC 102, Colgate University

	Implements a sparse matrix using hash tables.
	Your code goes here.
	See instructions for explanation of methods.

	You should change DEBUG to false when your testing is complete.
*/

import java.io.*;
import java.util.*;

public class MovieGraph
{

	// Debugging output
	private static final boolean DEBUG = true;
	private void pdbg(String s)
	{
		if (DEBUG)
			System.err.println(s);
	}

	// Constructor
	public MovieGraph(String filename) throws IOException, SecurityException, FileNotFoundException
	{

		// for debugging
		pdbg(filename);

	}

	// return the movies in which an actor has appeared
	public Iterable<String> getMovies(String actor)
	{
		// for debugging
		pdbg(actor);

		return null;
	}

	// return the actors in a movie
	public Iterable<String> getActors(String movie)
	{
		// for debugging
		pdbg(movie);

		return null;
	}

	// return the co-stars of an actor (over all movies)
	public Iterable<String> getCoStars(String actor)
	{
		// for debugging
		pdbg(actor);

		return null;
	}

	// return whether an actor has been in a movie
	public boolean isMatch(String actor, String movie)
	{
		// for debugging
		pdbg(actor + " " + movie);

		return false;
	}

	// return the movies in which two given actors have appeared together
	public Iterable<String> getMovieLinks(String actor1, String actor2)
	{
		// for debugging
		pdbg(actor1 + " " + actor2);

		return null;
	}
}
